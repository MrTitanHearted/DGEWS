# DGEWS
DGEWS is a simple toy windowing system for only learning purposes.
